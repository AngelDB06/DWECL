export class Puntos {
    constructor(x, y) {
        this.x= x;
        this.y=y;
    }
}

export class Lineas {
    constructor(p1, p2) {
        this.p1=p1;
        this.p2=p2;
    }
}