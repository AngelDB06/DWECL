export class Alumnos {
    constructor(id, nombre) {
        this.id=id;
        this.nombre=nombre;
        this.nm=5.00;
    }
}